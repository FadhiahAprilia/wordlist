import requests

api_key = '86dbe458-b138-4f0b-b8c5-d89bcf873eed'
word = 'potato'
url = f'https://dictionaryapi.com/api/v3/references/collegiate/json/test?key=86dbe458-b138-4f0b-b8c5-d89bcf873eed'

res = requests.get(url)

definitions = res.json()

for definition in definitions:
    print(definitions)